#!/data/data/com.termux/files/usr/bin/bash

echo "🔰 Batavia Reserve v5.0 Installer"
APK_URL="https://example.com/batavia.apk"  # Ganti dengan direct link
APK_FILE="batavia-reserve.apk"

echo "📥 Mengunduh APK..."
wget -O "$APK_FILE" "$APK_URL"

if [ -f "$APK_FILE" ]; then
  echo "✅ Unduhan berhasil, memulai instalasi..."
  termux-open "$APK_FILE"
else
  echo "❌ Gagal mengunduh APK. Periksa URL atau koneksi Anda."
fi
